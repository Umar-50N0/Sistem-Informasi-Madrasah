
<div class="row"> 
    <div class="col-md-10 col-sm-12 col-xs-12">                     
        
        <h2> Selamat Datang</h2>
        <p>Sistem Informasi ini dibuat untuk membantu Madrasah Nurul Anwar dalam melayani pendaftaran secara online.
        Sistem Informasi ini masih banyak kekurangan, untuk itu pengembang berharap mendapat 
        masukan-masukan guna memperbaiki kekurangan yang ada. Dan pengembang berharap semoga Sistem Informasi ini dapat bermanfaat 
        untuk kemajuan Madrasah Nurul Anwar</p>           
	</div>                
</div>


 
