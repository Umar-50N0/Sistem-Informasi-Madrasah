<div class="container" >
<div id="page-inner">
<div class="row">
<div class="row text-center  ">
    	<div class="col-md-12 wow fadeInDown" >
        	<h2> KEGIATAN DTA NURUL ANWAR</h2><br />
        </div>
    </div>
<div class="col-md-4">
    <div class="panel panel-default">
	<div class="panel-body">
		<div class="media">
            <div class="pull-left">
                <img class="img-responsive" src="<?php echo base_url('assets/upload/image/logo-dta.png') ?>">
            </div>
        </div>
	</div>
	<div class="panel-body">
	<div class="media-body">
			<label>Nama lembaga</label>
            <label>:</label>
            <label>DTA Nurul Anwar</label><br />
            <label>No Piagam</label>
            <label>:</label>
            <label>4320919025</label>
            </div>
    </div>
	</div>
</div>
<div class="col-md-8 col-sm-8">
    <div class="panel panel-default">
    
    <div class="panel-body">
        <ul class="nav nav-pills">
            <li class="active"><a href="#ngajibengi" data-toggle="tab">Ngaji Bengi</a></li>
            <li class=""><a href="#hadroh" data-toggle="tab">Hadroh</a></li>
        	
        </ul>

        <div class="tab-content">
            
            <div class="tab-pane fade active in" id="ngajibengi">
                <p>
                	Ngaji bengi adalah salah satu kegiatan rutin mingguan yang diadakan di Madrasah Nurul Anwar.
                	Kegiatan ini dilaksanakan setiap malam jum'at ba'da maghrib. Santri yang mengikuti kegiatan ngaji bengi tidak langsung pulang
                	setelah jam pelajaran usai. Hal yang dilakukan dalam kegiatan ini adalah membaca beberapa surat Al-quran diantaranya adalah 
                	membaca surat Yasin, surat Al-Waqi'ah, surat Al-Kahfi atau Ar-Rahman. Melalui kegiatan ngaji bengi ini, diharapkan santri 
                	dapat membiasakan diri untuk mengaji Al-qur'an di rumah.
                </p>
            </div>
            
            <div class="tab-pane fade" id="hadroh">
                <p>
                	Hadroh atau disebut juga dengan ketipringan adalah salah satu kegiatan kesenian yang ada di Madrasah Nurul Anwar.
                	Hadroh merupakan kesenian musik menggunakan alat-alat musik rebana. Terdiri dari 9-10 orang per grup. Lagu yang dilantunkan
                	dalam kegiatan ini adalah lagu-lagu  qasidah. Hadroh merupakan kegiatan ekstra kurikuler di Madrasah Nurul Anwar. Jadwal
                	Kegiatannya dilaksanakan setiap minggu pagi pukul 08.00 WIB sampai dengan selesai.
                </p>
                <p>
                	Hadroh yang dibimbing oleh Ust.Soma ini sering tampil di acara-acara keagamaan baik di acara Madrasah Nurul Anwar sendiri 
                	ataupun diundang  untuk pentas di tempat lain. Melalui kegiatan ini, diharapkan santri dapat melakukan kegiatan yang postif
                	dan dapat mengembangkan bakatnya.
                </p>

                            
            </div>

                                    
            </div>
        </div>
    </div>
    </div>
</div>
</div>
</div>
</div>