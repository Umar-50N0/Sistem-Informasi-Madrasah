</div>
</div>
</div>
<!--  end  Context Classes  -->
</div>
</div>
       <!-- /. ROW  -->
</div>
</div>
             <!-- /. PAGE INNER  -->
</div>
         <!-- /. PAGE WRAPPER  -->
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="<?php echo base_url('assets/js/jquery-1.10.2.js');?>"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="<?php echo base_url('assets/js/jquery.metisMenu.js');?>"></script>
    <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
</script>
     <!-- DATA TABLE SCRIPTS -->
    <script src="<?php echo base_url('assets/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('assets/js/dataTables/dataTables.bootstrap.js');?>"></script>
    <script src="<?php echo base_url('assets/js/jquery-ui.js');?>"></script>
 
    <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- HIGHCHARTS SCRIPTS -->
    <script src="<?php echo base_url('assets/js/highcharts.js') ?>"></script>
         <!-- CUSTOM SCRIPTS -->
    <script src="<?php echo base_url('assets/js/custom.js');?>"></script>
    
   
</body>
</html>
