<html>
<head>
<title>Datepicker</title>
<link href="<?php echo base_url(); ?>datepicker/rfnet.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo base_url(); ?>datepicker/datetimepicker_css.js"></script>
</head>
<body>
<table>
<tr>
<td>Tanggal Lahir</td>
<td><a href="javascript:NewCssCal('ttl','ddmmyyyy')"><input type="text" name="ttl" id="ttl" size="20" />
<img src="<?php echo base_url(); ?>datepicker/images/cal.gif" width="16" height="16" alt="Pilih tanggal" />
</a></td>
</tr>
</table>
</body>
 
</html>