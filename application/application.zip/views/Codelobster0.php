<?php
//Edit
	public function edit($id_berita){ //awal fungsi
		$berita		=$this->berita_model->detail($id_berita);
		$kategori	=$this->kategori_model->listing();
		$akhir		= $this->berita_model->akhir();
		
		// Validasi
		$v	= $this->form_validation;
		$v->set_rules('judul','Judul','required',
					array('require'	=> 'Judul harus diisi!'));
					
		$v->set_rules('isi','Isi','required',
					array('require'	=> 'Isi berita harus diisi!'));
					
		if($v->run()) { //awal run
		// kalau ada gambar
		if(!empty($_FILES['gambar']['name'])){
			
			
		// Masuk database
		else{
				$upload_data				= array('uploads' =>$this->upload->data());
				// Image Editor
				$config['image_library']	= 'gd2';
				$config['source_image'] 	= './assets/upload/image/'.$upload_data['uploads']['file_name']; 
				$config['new_image'] 		= './assets/upload/image/thumbs/';
				$config['create_thumb'] 	= TRUE;
				$config['quality'] 			= "100%";
				$config['maintain_ratio'] 	= TRUE;
				$config['width'] 			= 360; // Pixel
				$config['height'] 			= 360; // Pixel
				$config['x_axis'] 			= 0;
				$config['y_axis'] 			= 0;
				$config['thumb_marker'] 	= '';
				$this->load->library('image_lib', $config);
				$this->image_lib->resize();
				
				// hapus gambar lama
				if($berita->gambar != ""){
			unlink('./assets/upload/image/'.$berita->gambar);
			unlink('./assets/upload/image/thumbs/'.$berita->gambar);
				}
		//hapus gambar lama
				
			$i 			= $this->input;
			$slug 		= $url_akhir.'-'.url_title($i->post('judul'),'dash', TRUE);
			$data 		= array(	'id_berita'				=> $id_berita,
									'judul'					=> $i->post('judul'),
									'id_kategori_berita'	=> $i->post('id_kategori_berita'),
									'isi'					=> $i->post('isi'),
									'gambar'				=> $upload_data['uploads']['file_name'],
									'id_user'				=> $this->session->userdata('id'),
									'status_berita'			=> $i->post('status_berita'),
									'jenis_berita'			=> $i->post('jenis_berita')				
							);
			$this->berita_model->tambah($data);
			$this->session->set_flashdata('sukses','Berita berhasil diubah');
			redirect(base_url('admin/berita'));
		}// End masuk database
		}else{ //awal else upload tanpa gambar
			//upload tanpa gambar
			$i 			= $this->input;
			$slug 		= $url_akhir.'-'.url_title($i->post('judul'),'dash', TRUE);
			$data 		= array(	'id_berita'				=> $id_berita,
									'judul'					=> $i->post('judul'),
									'id_kategori_berita'	=> $i->post('id_kategori_berita'),
									'isi'					=> $i->post('isi'),
									'id_user'				=> $this->session->userdata('id'),
									'status_berita'			=> $i->post('status_berita'),
									'jenis_berita'			=> $i->post('jenis_berita')				
							);
			$this->berita_model->tambah($data);
			$this->session->set_flashdata('sukses','Berita berhasil diubah');
			redirect(base_url('admin/berita'));
		}//akhir else upload tanpa gambar
		}//akhir run
		$data	= array('title'		=>'Tambah Berita',
						'kategori'		=>$kategori,
						'berita'	=> $berita,
						'isi'		=>'admin/berita/edit');
		$this->load->view('admin/layout/wrapper',$data);
	}//akhir fungsi